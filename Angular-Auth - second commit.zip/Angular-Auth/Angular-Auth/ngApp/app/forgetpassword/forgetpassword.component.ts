import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { MatSnackBar } from '@angular/material/snack-bar';


@Component({
  selector: 'app-forgetpassword',
  templateUrl: './forgetpassword.component.html',
  styleUrls: ['./forgetpassword.component.css']
})
export class ForgetpasswordComponent implements OnInit {

  resetData = {
    email : ''
  }

  constructor(private _auth : AuthService,private snackbar : MatSnackBar) { }

  ngOnInit(): void {
  }

  onSubmit(){
    console.log(this.resetData)
    this._auth.forgetpassword(this.resetData).subscribe(res => 
      {
        console.log('sucesss')
        this.snackbar.open("Password sent to your email !!!",'Dismiss',{duration : 2000})
      },
    err => {
      console.log(err)
      this.snackbar.open(err.error,'Dismiss',{duration : 2000})
    })
  }

}
