import { Component, OnInit } from '@angular/core';
import { EventService } from '../event.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-special-events',
  templateUrl: './special-events.component.html',
  styleUrls: ['./special-events.component.css']
})
export class SpecialEventsComponent implements OnInit {

  specialevents = []
  constructor(private _eventservice : EventService,private _router : Router,private _authservice : AuthService,
    private snackbar : MatSnackBar) { }

  ngOnInit(){
    this._eventservice.getSpecialEvent().subscribe(
      res => {
        console.log(res),
        this.specialevents = res
      },err => {
        if(err instanceof HttpErrorResponse){
          if(err.status === 401){
            this._router.navigate(['/login'])
          }
        }
      }
    )
    }

    deletefromcart(response){
      if(this._authservice.loggedIn()){
        this.snackbar.open("Removed from Cart",'Dismiss',{duration : 2000})
        console.log(response._id)
         this._authservice.deleteEvent(response).subscribe(
          response => {
            console.log(response)
            this._router.navigate(['/events'])
          },
          err => console.log(err)
           ) 
        } else {
        this.snackbar.open("Kindly Login to your account",'Dismiss',{duration : 2000})
        this._router.navigate(['/login'])
        return false
      }
    }

}
