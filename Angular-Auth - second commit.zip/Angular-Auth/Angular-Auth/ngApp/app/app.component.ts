import { Component , OnInit, DoCheck} from '@angular/core';
import { AuthService } from './auth.service';
import {MatBadgeModule} from '@angular/material/badge';
import {MatIconModule} from '@angular/material/icon';
import { EventService } from './event.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit , DoCheck {
  title = 'ngApp';
  public cartcount : number = 0

  constructor(public  _authservice : AuthService,private _eventservice : EventService) { }

  ngDoCheck(){
    if(this._authservice.loggedIn()){
     this._eventservice.getSpecialEvent().subscribe( data => this.cartcount = data.length
       ,err => console.log(err))
    }else{
      this.cartcount = 0
    }}
  
  ngOnInit(){
    if(this._authservice.loggedIn()){
    this._eventservice.getSpecialEvent().subscribe(
      res => {
        console.log(res),
        this.cartcount = res.length
      },err => {
        console.log(err)
      }
    )
    }else{
      this.cartcount = 0
    }
  }

  // cartvalue(){
  //   this._eventservice.notify.subscribe( data => {
  //     console.log(data)
  //     this.cartcount = data
  //   });
  // }

}
