import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginUserData = {
    email : '',
    password : ''
  }

  constructor(private _auth : AuthService,private _router : Router,private snackbar : MatSnackBar) { }

  ngOnInit(): void {
  }
  
  loginUser(message){
    this._auth.loginUser(this.loginUserData).subscribe(
      res => {
        console.log(res)
        localStorage.setItem('token',res.token)
        this.snackbar.open(message,'Dismiss',{duration : 2000})
        this._router.navigate(['/special'])
      },
      err => {
        console.log(err)
        this.snackbar.open(err.error,'Dismiss',{duration : 2000})
      }
    )
  }



}
