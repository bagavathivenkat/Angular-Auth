const express = require('express')
const jwt = require('jsonwebtoken')
const router = express.Router()
var { Users, Carts} = require('../models/user')
const mongoose = require('mongoose')
const db = "mongodb+srv://dbuser:dbuser@cluster0-eqyyv.mongodb.net/test?retryWrites=true&w=majority"

mongoose.connect(db, {useUnifiedTopology: true , useNewUrlParser: true} ,err => {
    if(err){
        console.error('error' +err)
    } else {
        console.log('connected to mongo db')
    }
})

router.get('/',(req,res) => {
res.send('from api routes')
})


function verifyToken(req , res, next){
  if(!req.headers.authorization){
    return res.status(401).send('unauthorized request')
  }
  let token = req.headers.authorization.split(' ')[1]
  if(token === 'null'){
    return res.status(401).send('unauthorized token')
  }
  let payload = jwt.verify(token,'secretkey')
  if(!payload){
    return res.status(401).send('unauthorized token')
  }
  req.userId = payload.subject
  next()
}

router.post('/register' , (req,res) => {
    let userdata = req.body
    let user = new User(userdata)
    user.save((error , registereduser) => {
        if(error){
            console.log(error)
        } else {
          let payload = { subject : registereduser._id}
          let token = jwt.sign(payload,'secretkey')
            res.status(200).send({token})
        }
    })
})

router.post('/login' , (req,res) => {
    let userdata = req.body
    // let user = new User(userdata)
    User.findOne({email : userdata.email} , (error , user) => {
        if(error){
            console.log(error)
        } else {
            if(!user){
                res.status(401).send('Invalid email')
            } else {
                if( user.password !== userdata.password){
                    res.status(401).send('Invalid password')
                } else {
                  let payload = { subject : user._id}
                  let token = jwt.sign(payload,'secretkey')
                    res.status(200).send({token})
                }
            }
        }
    })
})

router.get('/events', (req,res) => {
    let events = [
      {
        "_id": "1",
        "name": "Samsung Galaxy J8",
        "description": "Black,64 Gb",
        "price" : "15000 ",
        "imagepath" : "https://i.gadgets360cdn.com/products/large/1532351323_635_samsung_galaxy_j8.jpg",
        "date": "2017-04-23T18:25:43.511Z"
      },
      {
        "_id": "2",
        "name": " Redmi 8A",
        "description": "Sunset Red ,32 Gb",
        "price" : "6000 ",
        "imagepath" : "https://i.gadgets360cdn.com/products/large/1532351323_635_samsung_galaxy_j8.jpg",
        "date": "2012-04-23T18:25:43.511Z"
      },
      {
        "_id": "3",
        "name": "Vivo V17 Pro",
        "description": "Midnight Ocean Black,128 Gb",
        "price" : "29999 ",
        "imagepath" : "https://i.gadgets360cdn.com/products/large/1532351323_635_samsung_galaxy_j8.jpg",
        "date": "2012-04-23T18:25:43.511Z"
      }
    ]
     res.json(events)
})

router.get('/specialevents',verifyToken , (req,res) => {
    let specialevents = [
      {
        "_id": "1",
        "name": "Samsung Galaxy J8",
        "description": "Black,64 Gb",
        "price" : " ₹15000 ",
        "imagepath" : "https://i.gadgets360cdn.com/products/large/1532351323_635_samsung_galaxy_j8.jpg",
        "date": "2017-04-23T18:25:43.511Z"
      }
    ]
     res.json(specialevents)
})

//  router.post('\cart',(req,res) => {
//   let userdata = req.body
//   let user = new User(userdata)
//   user.save((error , response) => {
//       if(error){
//           console.log(error)
//       } else {
//         console.log(response)
//       }
//  })
// })

router.post('/cart',(req,res) => {
  let userdata = req.body
  let cart = new Carts(userdata)
  cart.save((error , userdata) => {
    if(error){
      console.log(error)
    } else {
      console.log(userdata)
    }
  })
})

module.exports = router