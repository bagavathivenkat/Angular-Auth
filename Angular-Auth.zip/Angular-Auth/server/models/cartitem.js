const mongoose = require('mongoose')
const Schema = mongoose.Schema
const userSchema = new Schema({
    _id: Number,
    name: String,
    description : String,
    price : Number,
    imagepath : String,
    date: Date
})
module.exports = mongoose.model('user',userSchema,'users')