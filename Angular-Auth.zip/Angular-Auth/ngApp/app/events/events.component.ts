import { Component, OnInit ,Injectable} from '@angular/core';
import { EventService } from '../event.service';
import { AuthService } from '../auth.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router} from '@angular/router';


@Component({
  selector: 'app-events',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.css']
})
export class EventsComponent implements OnInit {

  
  events = []
  specialevents = [] 

  constructor(private _eventservice : EventService,private _router : Router,
    private _authservice : AuthService,private snackbar : MatSnackBar) { }

  ngOnInit(){
  this._eventservice.getEvent().subscribe(
    res => this.events = res,
    err => console.log(err)
  )
  }

  addtocart(response){
    if(this._authservice.loggedIn()){
      this.snackbar.open("Added To Cart",'Dismiss',{duration : 2000})
       this._authservice.postSpecialEvent(response).subscribe(
        res => console.log(res),
        err => console.log(err)
         )
      } else {
      this.snackbar.open("Kindly Login to your account",'Dismiss',{duration : 2000})
      this._router.navigate(['/login'])
      return false
    }
  }

}
