import { Injectable } from '@angular/core';
import {HttpClient , HttpHeaders , HttpResponse } from '@angular/common/http';

const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' })};

@Injectable({
  providedIn: 'root'
})
export class EventService {

  private _eventurl = "http://localhost:3000/api/events"
  private _specialurl = "http://localhost:3000/api/specialevents"

  constructor(private http : HttpClient) { }

  getEvent(){
    return this.http.get<any>(this._eventurl)
  }

  getSpecialEvent(){
    return this.http.get<any>(this._specialurl)
  }

  

}
