import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registerUserData = {
    email : '',
    password : ''
  }

  constructor(private _auth : AuthService,private _router : Router,private snackbar : MatSnackBar) { }

  ngOnInit(): void {
  }
  registerUser(message) {
    this._auth.registerUser(this.registerUserData).subscribe(
      res => {
        console.log(res)
        localStorage.setItem('token',res.token)
        this.snackbar.open(message,'Dismiss',{duration : 2000})
        this._router.navigate(['/special'])
      },
      err => console.log(err)
    )
  }

}
