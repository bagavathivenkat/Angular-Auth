const mongoose = require('mongoose')
var Schema = mongoose.Schema

var userSchema = new Schema({
    email : String,
    password : String
})

var cartSchema = new Schema({
    _id: Number,
    name: String,
    description : String,
    price : Number,
    imagepath : String,
    date: Date
})

// var users = mongoose.model('allUsers',loginUserSchema);  

var Users = mongoose.model('user', userSchema, 'users');
var Carts = mongoose.model('carts', cartSchema, 'carts');

module.exports = {
    Users,Carts
};