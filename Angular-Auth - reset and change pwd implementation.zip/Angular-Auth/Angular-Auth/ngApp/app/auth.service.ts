import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient } from '@angular/common/http'
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private _url = "http://localhost:3000/api/register"
  private _loginurl = "http://localhost:3000/api/login"
  constructor(private http : HttpClient , private _router : Router,private snackbar : MatSnackBar) { }

  registerUser(user){
    return this.http.post<any>(this._url,user)
  }

  loginUser(user){
    return this.http.post<any>(this._loginurl,user)
  }

  loggedIn(){
    return !!localStorage.getItem('token')
  }

  getToken(){
    return localStorage.getItem('token')
  }
  loggedOut(){
   localStorage.removeItem('token')
   this.snackbar.open('Loggedout successfully !!!','Dismiss',{duration : 2000})
    this._router.navigate(['/events'])
  }

   postSpecialEvent(response){
     return this.http.post<any>("http://localhost:3000/api/cart" ,response)
   }

   deleteEvent(response){
    return this.http.delete<any>("http://localhost:3000/api/removecart/" +response._id,response)
  }

  forgetpassword(data){
    return this.http.put<any>("http://localhost:3000/api/forgetpassword" ,data)
  }

  changepassword(pwd,email){
    return this.http.put<any>("http://localhost:3000/api/changepassword" ,{pwd,email})
  }
}
