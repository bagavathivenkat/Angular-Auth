import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {

  loggedUser = {
    newpassword : '',
    confirmpassword : ''
  }
  constructor(private _auth : AuthService,private _router : Router,private snackbar : MatSnackBar) { }

  ngOnInit(): void {
  }

  changepassword(){
    this._auth.changepassword(this.loggedUser.newpassword,localStorage.getItem('accountname')).subscribe(
      res => {
        this.snackbar.open(res.message,'Dismiss',{duration : 2000})
        this._router.navigate(['/events'])
      },
      err => {
        console.log(err)
        this.snackbar.open(err.error,'Dismiss',{duration : 2000})
      }
     )}

}
